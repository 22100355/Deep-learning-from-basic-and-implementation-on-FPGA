import # whatever you need

if __name__ == "__main__":

   # you need to add ...

   X = np.array([[0,1,0]])
   z = net.inference(X)
   print("X: ", X, "==>", z)

