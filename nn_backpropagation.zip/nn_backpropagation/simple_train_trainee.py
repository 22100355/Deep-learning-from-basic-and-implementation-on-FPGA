import # whatever you need

if __name__ == "__main__":

    # you need to add ...

    net.train(X, Y, 1000)

    # add more code if you need
