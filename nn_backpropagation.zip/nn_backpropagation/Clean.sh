#!/bin/bash

/bin/rm -rf __pycache__
/bin/rm -f  simple_all.pyc
/bin/rm -f  simple.pyc
/bin/rm -f  simple_infer.pyc
/bin/rm -f  simple_train.pyc
