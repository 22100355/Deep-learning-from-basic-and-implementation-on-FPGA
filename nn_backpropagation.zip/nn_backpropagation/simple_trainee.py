import numpy as np
from matplotlib import pyplot as plt

def sigmoidFunction(z, derivative=False):
    """derivative: get normal when false, while derivative when true"""
    ...

def lossFunction(Out, Desired):
    """Out: result of forward
       Desired: desired result
       It calculate Sum of Squared Error."""
    ...

class NeuralNetwork:
    def __init__(self, n_x, n_h, n_y):
        """n_x: number of input nodes
           n_h: number of hidden nodes
           n_y: number of output nodes"""
        ...

    def feedforward(self, In):
        """In: input data"""
        ...

    def backprop(self, In, Out, Desired):
        """In: input data
           Out: the result of forwared propagation
           Desired: desired value
           application of the chain rule to find derivative of the loss function
           with respect to W2 and W1"""
        ...

if __name__ == "__main__":
    X = np.array([[0,0,1],
                  [0,1,1],
                  [1,0,1],
                  [1,1,1]])
    Y = np.array([[0],[1],[1],[0]])

    nn = NeuralNetwork(X.shape[1],4,Y.shape[1])

    loss_values = []
    for i in range(1000):
        z = nn.feedforward(X)
        nn.backprop(X, z, Y)
        loss = lossFunction(z, Y)
        loss_values.append(loss)

    print(nn.output)

    #plt.figure()
    plt.plot(loss_values)
    plt.xlabel("Iterations"); plt.xlim(-10, len(loss_values))
    plt.ylabel("Loss")
    plt.show()
