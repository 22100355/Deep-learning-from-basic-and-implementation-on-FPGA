#!/bin/bash

/bin/rm -f  vitis_hls.log
/bin/rm -f  vivado_hls.log
/bin/rm -fr proj_lenet
/bin/rm -f  resized.png
