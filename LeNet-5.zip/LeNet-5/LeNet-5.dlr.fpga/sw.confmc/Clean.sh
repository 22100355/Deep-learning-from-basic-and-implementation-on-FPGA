#!/bin/bash

/bin/rm -rf obj
/bin/rm -f  lenet
/bin/rm -f  resized.png reverted.png
