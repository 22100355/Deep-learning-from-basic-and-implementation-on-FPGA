#!/bin/bash

/bin/rm -rf src/__pycache__
/bin/rm -rf train test
/bin/rm -rf checkpoints
/bin/rm -f  lenet5_params.h x.txt y.txt
