#!/bin/bash

/bin/rm -f  *.o
/bin/rm -fr obj
/bin/rm -f  lenet5
/bin/rm -f  resized.png  reverted.png
