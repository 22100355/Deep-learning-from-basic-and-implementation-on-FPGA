# __init__.py

from .my_mnist import *
