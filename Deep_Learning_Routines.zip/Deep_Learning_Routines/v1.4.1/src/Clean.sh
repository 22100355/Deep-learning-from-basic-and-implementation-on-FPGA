#!/bin/bash

/bin/rm -f  libdlr.so
/bin/rm -f  libdlr.a
/bin/rm -rf obj lib
