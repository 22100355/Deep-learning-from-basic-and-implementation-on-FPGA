#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>

#include "dlr_common.h"
#include "global_defines.h"
#include "convolution_2d_wrapper.h"

#define MINVAL 10

#define QuoteIdent(ident) #ident
#define QuoteMacro(macro) QuoteIdent(macro)

#define SIZE_ALL (((SIZE_X+SIZE_W+SIZE_Z+SIZE_B+SIZE_S+SIZE_P+3)/4)*4) // in bytes, word aligned
DTYPE *shared_mem=NULL;

int main (int argc, char *argv[])
{
    extern void fill_data();
    extern void print_data();

    #if !defined(__SYNTHESIS__)
    dlrInfo("data type                %s\n"   , QuoteMacro(DTYPE));
    dlrInfo("sizeof(data type)        %ld\n"  , sizeof(DTYPE));
    dlrInfo("num of channels          %d\n"   , N_C);
    dlrInfo("num of filters (kernels) %d\n"   , N_F);
    dlrInfo("featre dimension         %dx%d\n", N_X, N_X);
    dlrInfo("kernel dimension         %dx%d\n", N_W, N_W);
    dlrInfo("stride                   %d\n"   , N_S);
    dlrInfo("padding                  %d\n"   , N_P);
    dlrInfo("result dimension         %dx%d\n", N_Z, N_Z);
    dlrInfo("size all                 %d\n"   , SIZE_ALL);
    dlrInfo("depth size               %d\n"   , SIZE_ALL/4);
    #endif

    shared_mem = (DTYPE*)malloc(SIZE_ALL);
    memset(shared_mem, 0xFF, SIZE_ALL);
    printf("shared_mem ready\n");

    fill_data();
    
    extern void Convolution2dWrapper(DTYPE*);
    auto t1 = std::chrono::high_resolution_clock::now();
    Convolution2dWrapper(shared_mem);
    auto t2 = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
    print_data();

    printf("\n\n%5.3f ms\n", (float)duration/1000);

    free(shared_mem);
}

//  +----------------------+(high)
//  | Padding              |
//  +----------------------+
//  | Stride               |
//  +----------------------+
//  |                      |
//  | Bias                 |
//  +----------------------+
//  |                      |
//  | Z                    |
//  +----------------------+
//  |                      |
//  | W                    |
//  +----------------------+
//  |                      |
//  | X                    |
//  +----------------------+(low)
//   shared_mem
void fill_data()
{
    DTYPE *pt;

    pt = (DTYPE*)shared_mem; // for input image
    for (int idx=0; idx<N_C; idx++) {
    for (int idy=0; idy<N_X; idy++) {
    for (int idz=0; idz<N_X; idz++) {
        *pt++ = ((((idx*N_X*N_X)+(idy*N_X)+idz))%MINVAL);
        //feature_map[idx][idy][idz] = (idx*N_X*N_X)+(idy*N_X)+idz;
    }
    }
    }

    pt = (DTYPE*)&shared_mem[NUM_X]; // for kernel
    for (int idw=0; idw<N_F; idw++) {
    for (int idx=0; idx<N_C; idx++) {
    for (int idy=0; idy<N_W; idy++) {
    for (int idz=0; idz<N_W; idz++) {
        *pt++ = (idy==idz) ? 1 : 0; // diagonal
        //kernel[idw][idx][idy][idz] = (idy==idz) ? 1 : 0; // diagonal
    }
    }
    }
    }

    pt = (DTYPE*)&shared_mem[NUM_X+NUM_W]; // for output
    for (int idx=0; idx<N_F; idx++) {
    for (int idy=0; idy<N_Z; idy++) {
    for (int idz=0; idz<N_Z; idz++) {
        *pt++ = 0;
    }
    }
    }

    pt = (DTYPE*)&shared_mem[NUM_X+NUM_W+NUM_Z]; // bias
    for (int idz=0; idz<N_F; idz++) {
        *pt++ = 0;
        //bias[idz] = 0;
    }

    uint8_t *ct = (uint8_t*)&shared_mem[NUM_X+NUM_W+NUM_Z+NUM_B];
    *ct = N_S; // stride
     ct++;
    *ct = N_P; // padding
}

#define str_helper(s) #s
#define str(s) str_helper(s)

void print_data()
{
    DTYPE *pt;

    pt = (DTYPE*)shared_mem;
    for (int idx=0; idx<N_C; idx++) {
    for (int idy=0; idy<N_X; idy++) {
    for (int idz=0; idz<N_X; idz++) {
        if (!strcmp("int",str(DTYPE))) printf("%4d ", (int)*pt++);
        else printf("%8.3f ", (double)*pt++);
        //printf("%8.3f ", (float)feature_map[idx][idy][idz]);
    }
        printf("\n");
    }
        printf("\n");
    }
    printf("\n");

    pt = (DTYPE*)&shared_mem[NUM_X];
    for (int idw=0; idw<N_F; idw++) { // num of filters (num of out channels)
    for (int idx=0; idx<N_C; idx++) { // num of input channels
    for (int idy=0; idy<N_W; idy++) { // kernel dimension
    for (int idz=0; idz<N_W; idz++) {
        if (!strcmp("int",str(DTYPE))) printf("%4d ", (int)*pt++);
        else printf("%8.3f ", (double)*pt++);
        //printf("%8.3f ", (float)kernel[idw][idx][idy][idz]);
    }
        printf("\n");
    }
        printf("\n");
    }
        printf("\n");
    }
    printf("\n");

    pt = (DTYPE*)&shared_mem[NUM_X+NUM_W];
    for (int idx=0; idx<N_F; idx++) {
    for (int idy=0; idy<N_Z; idy++) {
    for (int idz=0; idz<N_Z; idz++) {
        if (!strcmp("int",str(DTYPE))) printf("%4d ", (int)*pt++);
        else printf("%8.3f ", (double)*pt++);
        //printf("%8.3f ", (float)result[idx][idy][idz]);
    }
        printf("\n");
    }
        printf("\n");
    }
}
