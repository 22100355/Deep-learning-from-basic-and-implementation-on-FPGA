/*
 * Copyright (c) 2019-2020 by Future Design Systems.
 * All right reserved.
 * http://www.future-ds.com
 *
 * @file convolution_2d_core.c
 * @brief This file contains 2 dimensional convolution routine.
 * @author FDS
 * @date Sep. 30, 2020
 */

#include "convolution_2d.hpp"
#include "convolution_2d_wrapper.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>

// Z = X @ W
// Z: output
// X: feature
// W: kernel
// It only deal with square matrix for both data and filter.
// It does support multi-channel.
// It does support strid.
// It does not support padding.
// It does not support dilation.
//
// 'shared_mem' contains 'X, W, bias, bias, Z, stride, padding'
//
//  +----------------------+(high)
//  | Padding              |
//  +----------------------+
//  | Stride               |
//  +----------------------+
//  |                      |
//  | Bias                 |
//  +----------------------+
//  |                      |
//  | Z                    |
//  +----------------------+
//  |                      |
//  | W                    |
//  +----------------------+
//  |                      |
//  | X                    |
//  +----------------------+(low)
//   shared_mem
//
void Convolution2dWrapper ( DTYPE *shared_mem )
{
#define PRAGMA_SUB(x) _Pragma (#x)
#define DO_PRAGMA(x) PRAGMA_SUB(x)
    #pragma HLS INTERFACE s_axilite port=return
    DO_PRAGMA(HLS INTERFACE m_axi   port=shared_mem\
                                    bundle=data\
                                    offset=slave\
                                    depth=M_AXI_DEPTH)
    #if !defined(__SYNTHESIS__)
    int rigor=0;
    int verbose=0;
    #endif
    // DO_PRAGMA(HLS RESOURCE variable=Z core=RAM_2P_LUTRAM)
    DTYPE   X     [N_C][N_X][N_X];
    DTYPE   W[N_F][N_C][N_W][N_W];
    DTYPE   Z[N_F][N_Z][N_Z];

    DTYPE   bias[N_B]; // N_B==N_F
    uint8_t stride;
    uint8_t padding;

    char *pt=(char*)shared_mem;
    memcpy(X, pt, SIZE_X);

    pt = (char*)&shared_mem[NUM_X];
    memcpy(W, pt, SIZE_W);

    pt = (char*)&shared_mem[NUM_X+NUM_W];
    memcpy(Z, pt, SIZE_Z);

    pt = (char*)&shared_mem[NUM_X+NUM_W+NUM_Z];
    memcpy(bias, pt, SIZE_B);

    pt = (char*)&shared_mem[NUM_X+NUM_W+NUM_Z+NUM_B];
    stride = *(uint8_t*)pt;
    
    pt++;
    padding = *(uint8_t*)pt;

    // addyour code
}

/*
 * Revision history
 *
 * 2020.07.01: Started by Ando Ki (adki@future-ds.com)
 */
