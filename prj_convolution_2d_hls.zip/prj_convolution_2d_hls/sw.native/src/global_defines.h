#pragma once
#define GLOBAL_DEFINES_H

#include <stdint.h>
//#define DTYPE         float
#define DTYPE         int
#define DTYPE_SIZE    4    // sizeof(DTYPE)
//#define CONV_FUNCTION Convolution2dInt
//#define CONV_FUNCTION Convolution2dFloat
//#define CONV_FUNCTION Convolution2dDouble

#define N_C         2   // num of channels (num of input channels)
#define N_F         2   // num of filters (kernels) (num of output channels)
#define N_X         8   // featre dimension
#define N_W         3   // kernel dimension
#define N_P         1   // pading 
#define N_S         1   // stride
#define N_B         N_F  // bias for each kernel
// #define N_D         0
#define N_Z        (((N_X-N_W+2*N_P)/N_S)+1)
// #define N_Z        (((N_X+2*N_P-N_D*(N_W-1)-1)/N_S)+1)

#define N_M         1    // num of mini batch (do not change, it does not support)
#define N_D         N_Z*N_Z
#define N_I         N_C*N_W*N_W
#define N_O         N_F

#define NUM_X  (N_C*N_X*N_X)     // in DTYPES
#define NUM_W  (N_C*N_F*N_W*N_W) // in DTYPES
#define NUM_Z  (N_F*N_Z*N_Z)     // in DTYPES
#define NUM_B  (N_B)             // in DTYPES
#define NUM_UX (N_M*N_D*N_I)     // in DTYPES
#define NUM_UW (N_O*N_I)         // in DTYPES
#define NUM_UZ (N_M*N_D*N_O)     // in DTYPES

#define SIZE_X  (DTYPE_SIZE*NUM_X) // in bytes
#define SIZE_W  (DTYPE_SIZE*NUM_W) // in bytes
#define SIZE_Z  (DTYPE_SIZE*NUM_Z) // in bytes
#define SIZE_B  (DTYPE_SIZE*NUM_B) // in bytes
#define SIZE_S   1                 // in bytes
#define SIZE_P   1                 // in bytes
#define SIZE_UX (DTYPE_SIZE*NUM_UX)// in bytes
#define SIZE_UW (DTYPE_SIZE*NUM_UW)// in bytes
#define SIZE_UZ (DTYPE_SIZE*NUM_UZ)// in bytes
// #define SIZE_D 1                   // in bytes

#define ADDR_X_OFFSET    0x00000000
#define ADDR_W_OFFSET   (ADDR_X_OFFSET+SIZE_X)
#define ADDR_Z_OFFSET   (ADDR_W_OFFSET+SIZE_W)
#define ADDR_B_OFFSET   (ADDR_Z_OFFSET+SIZE_Z)
#define ADDR_S_OFFSET   (ADDR_B_OFFSET+SIZE_B)
#define ADDR_P_OFFSET   (ADDR_S_OFFSET+SIZE_S)
// #define ADDR_D_OFFSET   (ADDR_P_OFFSET+SIZE_P)
