#pragma once
#ifdef __cplusplus
extern "C" {
#endif

#include "global_defines.h"

#if 0
// need to figure out how to expand macro, i.e., simple assignment
#define M_AXI_DEPTH  ((DTYPE_SIZE/4) /*32-bit-bus*/\
                     *((N_C*N_X*N_X) /*X*/\
                      +(N_C*N_F*N_W*N_W) /*W*/\
                      +(N_F*N_Z*N_Z) /*Z*/\
                      +N_F /*BIAS*/\
                      +1 ))/* STRIDE*/
#else
// #define M_AXI_DEPTH 111 // (444/4)
#define M_AXI_DEPTH  20129 // for padding=1 test, 
#endif

// Z = X @ W
// Z: output
// X: feature
// W: kernel
// It only deal with square matrix for both data and filter.
// It does support multi-channel.
// It does support stride.
// It does support padding.
// It does not support dilation.
//
// 'shared_mem' contains 'X, W, bias, bias, Z, stride, padding'
//
//  +----------------------+(high)
//  | Padding              |
//  +----------------------+
//  | Stride               |
//  +----------------------+
//  |                      |
//  | Bias                 |
//  +----------------------+
//  |                      |
//  | Z                    |
//  +----------------------+
//  |                      |
//  | W                    |
//  +----------------------+
//  |                      |
//  | X                    |
//  +----------------------+(low)
//   shared_mem
//
void Convolution2dWrapper ( DTYPE *shared_mem );

#ifdef __cplusplus
}
#endif
