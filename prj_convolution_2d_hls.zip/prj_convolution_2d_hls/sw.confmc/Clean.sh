#!/bin/bash

/bin/rm -rf obj
/bin/rm -f  conv2d
