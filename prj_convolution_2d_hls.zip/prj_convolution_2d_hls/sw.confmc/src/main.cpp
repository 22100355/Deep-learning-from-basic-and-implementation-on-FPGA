#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <chrono>
#include "conapi.h"
#include "trx_axi_api.h"
#include "convolution_2d.hpp" // no need to compile cpp

#define MINVAL 10

//------------------------------------------------------------------------------
unsigned int card_id=0;
con_Handle_t handle=NULL;

#define MEM_WRITE(A, B)        BfmWrite(handle, (unsigned int)(A), (unsigned int*)&(B), 4, 1)
#define MEM_READ(A, B)         BfmRead (handle, (unsigned int)(A), (unsigned int*)&(B), 4, 1)
#define MEM_WRITE_G(A,D,S,L)   BfmWrite(handle, (A), (D), (S), (L))
#define MEM_READ_G(A,D,S,L)    BfmRead (handle, (A), (D), (S), (L))

//------------------------------------------------------------------------------
#include "global_defines.h"

//------------------------------------------------------------------------------
// see hls/convolution_2d/ZED/impl/misc/drivers/convolution_2d_v1_0/src/xconvolution_2d_hw.h
#define ADDR_CSR            0xC0000000 // CONVOLUTION_2D internal CSR
#define ADDR_AP_CTRL       (ADDR_CSR+0x00)
#define ADDR_GIE           (ADDR_CSR+0x04)
#define ADDR_IER           (ADDR_CSR+0x08)
#define ADDR_ISR           (ADDR_CSR+0x0C)
#define ADDR_DATA          (ADDR_CSR+0x10) // csr address of offset for X
                                           // should be filled by 'ADDR_X_START'

//------------------------------------------------------------------------------
#define ADDR_X_START    0x00000000
#define ADDR_W_START   (ADDR_X_START+SIZE_X)  // 25088
#define ADDR_Z_START   (ADDR_W_START+SIZE_W)  // 98816
#define ADDR_B_START   (ADDR_Z_START+SIZE_Z)  // 328192
#define ADDR_S_START   (ADDR_B_START+SIZE_B)  // 328448
#define ADDR_P_START   (ADDR_S_START+SIZE_S)  // 328449

#define SIZE_ALL (((SIZE_X+SIZE_W+SIZE_Z+SIZE_B+SIZE_S+SIZE_P+4)/4)*4) // in bytes, word aligned

//------------------------------------------------------------------------------
//DTYPE   feature_map[N_C][N_X][N_X];
//DTYPE   kernel     [N_C][N_F][N_W][N_W];
//DTYPE   result     [N_F][N_Z][N_Z];
//DTYPE   bias       [N_B]; // N_B==N_F
//uint8_t stride=N_S;

int main(int argc, char *argv[])
{
    if ((handle=conInit(card_id, CON_MODE_CMD, CONAPI_LOG_LEVEL_INFO))==NULL) {
         printf("cannot initialize CON-FMC\n");
         return 0;
    }
    struct _usb usb;
    conGetUsbInfo( handle, &usb); // Get USB related information
    con_MasterInfo_t gpif2mst_info; // Get GPIF2MST information
    if (conGetMasterInfo(handle, &gpif2mst_info)) {
        printf("cannot get gpif2mst info\n");
        return -1;
    }
    #ifndef SILENCE
    extern void confmc_info(struct _usb usb, con_MasterInfo_t gpif2mst_info);
    confmc_info(usb, gpif2mst_info);
    #endif //SILENCE

    extern void test_convolution_2d();
    test_convolution_2d();

    return 0;
}

#define QuoteIdent(ident) #ident
#define QuoteMacro(macro) QuoteIdent(macro)

#define WAIT_FOR_READY {\
    int ap_idle, ap_idle_r;\
    unsigned int ap_addr;\
    ap_addr = ADDR_CSR;\
    while (1) {\
        MEM_READ(ap_addr, ap_idle_r);\
        ap_idle = (ap_idle_r >> 2) && 0x1;\
        if (ap_idle) break;\
    }}
#define GO_AND_WAIT_COMPLETE {\
    int ap_done, ap_done_r;\
    int ap_start, ap_data;\
    unsigned int ap_addr;\
    ap_addr = ADDR_CSR;\
    ap_data = 0x1;\
    MEM_WRITE(ap_addr, ap_data);\
    while (1) {\
        MEM_READ(ap_addr, ap_done_r);\
        ap_done = (ap_done_r >> 1) && 0x1;\
        if (ap_done) break;\
    }}

void test_convolution_2d()
{
    extern void set_offset();
    extern void fill_data( DTYPE **X, DTYPE **W, DTYPE **B, unsigned char *S, unsigned char *P);
    extern void print_data( DTYPE *E, DTYPE *X, DTYPE *W, DTYPE *B, unsigned char S, unsigned char P);

    printf("data type                %s\n", QuoteMacro(DTYPE));
    printf("num of channels          %d\n", N_C);
    printf("num of filters (kernels) %d\n", N_F);
    printf("featre dimension         %d\n", N_X);
    printf("kernel dimension         %d\n", N_W);
    printf("pading (do not change)   %d\n", N_P);
    printf("stride                   %d\n", N_S);
    printf("result dimension         %d\n", N_Z);
    printf("size all:                %d\n", SIZE_ALL);
    printf("\n");

    auto t1 = std::chrono::high_resolution_clock::now();
    set_offset();
    WAIT_FOR_READY;
    auto t2 = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
    printf("\n\n%10.3f ms spended for board ready\n", (float)duration/1000);

    t1 = std::chrono::high_resolution_clock::now();
    DTYPE *X; DTYPE *W; DTYPE *B; unsigned char S; unsigned char P;
    fill_data( &X, &W, &B, &S, &P);
    t2 = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
    printf("\n\n%10.3f ms spended for preperation\n", (float)duration/1000);

    t1 = std::chrono::high_resolution_clock::now();
    GO_AND_WAIT_COMPLETE
    t2 = std::chrono::high_resolution_clock::now();
    duration = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
    printf("\n\n%10.3f ms spended for layer operation\n", (float)duration/1000);

    DTYPE *E= (DTYPE *)malloc(N_F*N_Z*N_Z*sizeof(DTYPE));
    dlr::Convolution2d (
      E  //       TYPE     *out_data    // out_channel x out_size x out_size
    , X  // const TYPE     *in_data     // in_channel x in_size x in_size
    , W  // const TYPE     *kernel      // out_channel x in_channel x kernel_size x kernel_size
    , B  // const TYPE     *bias        // out_channel
    , N_Z// const uint16_t  out_size    // only for square matrix
    , N_X// const uint16_t  in_size     // only for square matrix
    , N_W// const uint8_t   kernel_size // only for square matrix
    , N_F// const uint16_t  bias_size   // out_channel
    , N_C// const uint16_t  in_channel  // number of input channels
    , N_F// const uint16_t  out_channel // number of filters (kernels)
    , N_S// const uint8_t   stride
    , N_P// const uint8_t   padding=0
    #if !defined(__SYNTHESIS__)
    , 0  // const int       rigor=0   // check rigorously when 1
    , 0  // const int       verbose=0 // verbose level
    #endif
    );

    print_data(E, X, W, B, S, P);

    if (X!=NULL) free(X);
    if (W!=NULL) free(W);
    if (B!=NULL) free(B);
    if (E!=NULL) free(E);
}

// It sets starting address of 'shared_mem' in the HW memory.
void set_offset()
{
    unsigned int data;

    data = ADDR_X_START;    MEM_WRITE(ADDR_DATA, data);
}

// Z = X @ W
// Z: output
// X: feature
// W: kernel
// It only deal with square matrix for both data and filter.
// It does support multi-channel.
// It does support strid.
// It does not support padding.
// It does not support dilation.
//
// 'shared_mem' contains 'X, W, bias, bias, Z, stride, padding'
//
//  +----------------------+(high)
//  | Padding              |
//  +----------------------+
//  | Stride               |
//  +----------------------+
//  |                      |
//  | Bias                 |
//  +----------------------+
//  |                      |
//  | Z                    |
//  +----------------------+
//  |                      |
//  | W                    |
//  +----------------------+
//  |                      |
//  | X                    |
//  +----------------------+(low)
//   shared_mem
void fill_data( DTYPE **X, DTYPE **W, DTYPE **B, unsigned char *S, unsigned char *P)
{
    unsigned int addr;
    DTYPE data;

    DTYPE *pt = (DTYPE *)malloc(N_C*N_X*N_X*sizeof(DTYPE));
    *X = pt;
    
    addr = ADDR_X_START;
    for (int idx=0; idx<N_C; idx++) {
    for (int idy=0; idy<N_X; idy++) {
    for (int idz=0; idz<N_X; idz++) {
        data = (((idx*N_X*N_X)+(idy*N_X)+idz)%MINVAL);
        *pt++ = data;
        MEM_WRITE(addr, data);
        addr += DTYPE_SIZE;
        //feature_map[idx][idy][idz] = (idx*N_X*N_X)+(idy*N_X)+idz;
    }
    }
    }

    pt = (DTYPE *)malloc(N_C*N_F*N_W*N_W*sizeof(DTYPE));
    *W = pt;

    addr = ADDR_W_START;
    for (int idw=0; idw<N_C; idw++) {
    for (int idx=0; idx<N_F; idx++) {
    for (int idy=0; idy<N_W; idy++) {
    for (int idz=0; idz<N_W; idz++) {
        data = (idy==idz) ? 1 : 0; // diagonal
        *pt++ = data;
        MEM_WRITE(addr, data);
        addr += DTYPE_SIZE;
        //kernel[idw][idx][idy][idz] = (idy==idz) ? 1 : 0; // diagonal
    }
    }
    }
    }

    // addr = ADDR_Z_START;
    // for (int idx=0; idx<N_C; idx++) {
    // for (int idy=0; idy<N_X; idy++) {
    // for (int idz=0; idz<N_X; idz++) {
    //     data = 0;
    //     MEM_WRITE(addr, data);
    //     addr += DTYPE_SIZE;
    
    //     //feature_map[idx][idy][idz] = (idx*N_X*N_X)+(idy*N_X)+idz;
    // }
    // }
    // }

    pt = (DTYPE *)malloc(N_F*sizeof(DTYPE));
    *B = pt;

    addr = ADDR_B_START;
    for (int idz=0; idz<N_F; idz++) {
        data = 0;
        *pt++ = data;
        MEM_WRITE(addr, data);
        addr += DTYPE_SIZE;
    }

    *S = (unsigned char)N_S;
    *P = (unsigned char)N_P;

    addr = ADDR_S_START; // stride
    data = (N_P<<8)|N_S; // should be 1
    MEM_WRITE(ADDR_S_START, data);
    // MEM_WRITE_G(ADDR_P_START, (unsigned int*)&data, 1, 1);

#if 0
    addr = ADDR_P_START; // padding
    data = N_P; // should be 1
    // MEM_WRITE(ADDR_P_START, data);
    MEM_WRITE_G(ADDR_P_START, (unsigned int*)&data, 1, 1);
#endif
}

void print_data( DTYPE *E, DTYPE *X, DTYPE *W, DTYPE *B, unsigned char S, unsigned char P)
{
    unsigned int addr;
    DTYPE data;
    int idx;
    int error=0;

    printf("[X data]\n");
    idx = 0;
    addr = ADDR_X_START;
    for (int idx=0; idx<N_C; idx++) {
    for (int idy=0; idy<N_X; idy++) {
    for (int idz=0; idz<N_X; idz++) {
        MEM_READ(addr, data);
        if (data!=X[idx]) error++;
        printf("%6X(%d) ", addr, (unsigned int)data);
        addr += DTYPE_SIZE;
        idx++;
        // printf("%f ", (float)data);
        //printf("%f ", (float)feature_map[idx][idy][idz]);
    }
        printf("\n");
    }
        printf("\n");
    }
    printf("\n");

    printf("[W data]\n");
    idx = 0;
    addr = ADDR_W_START;
    for (int idw=0; idw<N_C; idw++) {
    for (int idx=0; idx<N_F; idx++) {
    for (int idy=0; idy<N_W; idy++) {
    for (int idz=0; idz<N_W; idz++) {
        MEM_READ(addr, data);
        if (data!=W[idx]) error++;
        printf("%6X(%d) ", addr, (unsigned int)data);
        addr += DTYPE_SIZE;
        idx++;
        // printf("%f ", (float)data);
        //printf("%f ", (float)kernel[idw][idx][idy][idz]);
    }
        printf("\n");
    }
        printf("\n");
    }
    }
    printf("\n");

    DTYPE *Z = (DTYPE *)malloc(N_F*N_Z*N_Z*sizeof(DTYPE));
    DTYPE *pt=Z;

    printf("[Z data]\n");
    addr = ADDR_Z_START;
    for (int idx=0; idx<N_F; idx++) {
    for (int idy=0; idy<N_Z; idy++) {
    for (int idz=0; idz<N_Z; idz++) {
        MEM_READ(addr, data);
        *pt++ = data;
        printf("%6X(%d) ", addr, (unsigned int)data);
        addr += DTYPE_SIZE;
        // printf("%f ", (float)data);
        //printf("%f ", (float)result[idx][idy][idz]);
    }
        printf("\n");
    }
        printf("\n");
    }

    printf("[E data]\n");
    idx = 0;
    for (int idx=0; idx<N_F; idx++) {
    for (int idy=0; idy<N_Z; idy++) {
    for (int idz=0; idz<N_Z; idz++) {
        data = E[idx];
        if (data!=Z[idx]) error++;
        printf("%6X(%d) ", idx, (unsigned int)data);
        idx += 1;
    }
        printf("\n");
    }
        printf("\n");
    }

    if (error==0) printf("%s() OK\n", __func__);
    else          printf("%s() Mismatch %d out of %d\n", __func__, error, idx);
}

void confmc_info(struct _usb usb, con_MasterInfo_t gpif2mst_info)
{
    printf("USB information\n");
    printf("    DevSpeed         =%d%cbps\n", (usb.speed>10000) ? usb.speed/10000
                                                                : usb.speed/10
                                            , (usb.speed>10000) ? 'G' : 'M');
    printf("    BulkMaxPktSizeOut=%d\n", usb.bulk_max_pkt_size_out);
    printf("    BulkMaxPktSizeIn =%d\n", usb.bulk_max_pkt_size_in );
    printf("    IsoMaxPktSizeOut =%d\n", usb.iso_max_pkt_size_out );
    printf("    IsoMaxPktSizeIn  =%d\n", usb.iso_max_pkt_size_in  );
    fflush(stdout);

    printf("gpif2mst information\n");
    printf("         version 0x%08X\n", gpif2mst_info.version);
    printf("         pclk_freq %d-Mhz (%s)\n", gpif2mst_info.clk_mhz
                                               , (gpif2mst_info.clk_inv)
                                               ? "inverted"
                                               : "not-inverted");
    printf("         DepthCu2f=%d, DepthDu2f=%d, DepthDf2u=%d\n"
                                 , gpif2mst_info.depth_cmd
                                 , gpif2mst_info.depth_u2f
                                 , gpif2mst_info.depth_f2u);
    fflush(stdout);
}
