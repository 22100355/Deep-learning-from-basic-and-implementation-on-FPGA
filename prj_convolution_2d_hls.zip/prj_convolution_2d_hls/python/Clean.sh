#!/bin/bash

/bin/rm -f  *.o
/bin/rm -f  *.so
/bin/rm -f  *.pyc *.pyo
/bin/rm -rf __pycache__
