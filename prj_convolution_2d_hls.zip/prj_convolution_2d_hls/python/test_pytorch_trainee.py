#!/usr/bin/env python
"""
This file contains testing script.
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

#-------------------------------------------------------------------------------
__author__     = "Ando Ki"
__copyright__  = "Copyright 2020, Future Design Systems"
__credits__    = ["none", "some"]
__license__    = "FUTURE DESIGN SYSTEMS SOFTWARE END-USER LICENSE AGREEMENT"
__version__    = "0"
__revision__   = "0"
__maintainer__ = "Ando Ki"
__email__      = "contact@future-ds.com"
__status__     = "Development"
__date__       = "2020.04.25"
__description__= "Python script to test Convolution2d"

#-------------------------------------------------------------------------------
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.append("../../..")
import python as py
import python.modules.dlr_common as dlr_common
import python.torch as dlr
#import dlr_common as dlr
#import convolution_2d_wrapper as conv

#===============================================================================
def TestConvolution2d( dtype
                     , in_data
                     , kernel
                     , bias=None
                     , stride=1
                     , padding=0
                     , rigor=True
                     , verbose=True):
    """
    Calls PyTorch convolution and DLR convolution, and compares results.
    Returns 'True' 'out_data', 'nout_data' when the same, otherwize return 'False', '0', '0'
    Note that it uses PyTorch tensor and uses NumPy for DLR convolution.
    Note that PyTorch tensor is not mutable even it is list-like.
    :param dtype:
    :param in_data: [in_minibatch,in_channel,in_size,in_size]
    :param kernel: [in_channel,out_channel,kernel_size,kernel_size]
    :param bias: [out_channel]
    :param stride:
    :param padding:
    :param rigor:
    :param verbose:
    :return: 'True' 'out_data', 'nout_data' when the same, otherwize return 'False', '0', '0'
          state: True or False
          out_data: expected result
          nout_data: calculated result
    """
    # add your code
    return status, out_data, nout_data

#-------------------------------------------------------------------------------
def GenData(in_data, kernel, bias, dtype, random=False):
    if random:
        if dtype is torch.int32:
            in_data = (torch.rand(size=list(in_data.shape))*100).type(dtype)
            kernel = (torch.rand(size=list(kernel.shape))*100).type(dtype)
            if bias is not None: bias = (torch.rand(size=[kernel.shape[0]])*100).type(dtype)
        else:
            in_data = torch.rand(size=list(in_data.shape), dtype=dtype)
            kernel = torch.rand(size=list(kernel.shape), dtype=dtype)
            if bias is not None: bias = torch.rand(size=[kernel.shape[0]], dtype=dtype)
    else:
        v = 0
        for m in range(in_data.shape[0]): # minibatch
            for i in range(in_data.shape[1]): # in_channels
                for r in range(in_data.shape[2]): # rows (height)
                    for c in range(in_data.shape[3]): # columns (width)
                        in_data[m][i][r][c] = v
                        v += 1
        for o in range(kernel.shape[0]): # num of kernels (out_channel)
            for i in range(kernel.shape[1]): # num of in-channels
                for r in range(kernel.shape[2]): # rows
                    for c in range(kernel.shape[3]): # columns
                        if (r==c): kernel[o][i][r][c] = 1 # make diagonal matrix
                        else     : kernel[o][i][r][c] = 0
        if bias is not None:
            for b in range(bias.numel()): bias[b] = b+1
    return in_data, kernel, bias

#-------------------------------------------------------------------------------
def TestConvolution2dAll(dtype=torch.int32, random=True, rigor=False, verbose=False):
    """
    dtype = {torch.int32, torch.float32, torch.float64}
    """
    _fail_case    = [] # prepare empty dictionaly to keep error cases
    _in_minibatch = 1 # number of mini-batches (1 by default)
    _in_channels  = [1, 3]#[1, 2, 3, 32, 64, 128, 256, 512]
    _out_channels = [1, 5]#[1, 2, 3, 32, 64, 128, 256, 512] # number of kernels
    _in_sizes     = [32, 128]#[5, 8, 14, 28, 56, 112, 224]
    _kernel_sizes = [3, 5] # should be odd number
    _strides      = [1, 2, 5]#, 3, 4, 5] # upto kernel size
    _paddings     = [0, 1]#, 2] # a half of kernel size
    _biases       = [None, 2]

    count_ok, count_passed, count_fail=0, 0, 0
    count_all=len(_in_channels)*len(_out_channels)*len(_in_sizes)*len(_kernel_sizes)*len(_strides)*len(_paddings)*len(_biases)
    for in_channel in _in_channels:
        for out_channel in _out_channels:
            for in_size in _in_sizes:
                for kernel_size in _kernel_sizes:
                    if kernel_size > in_size:
                        count_passed+=len(_biases)*len(_strides)*len(_paddings)
                        continue
                    for tbias in [None, out_channel]:
                        in_data  = torch.zeros([_in_minibatch,in_channel,in_size,in_size], dtype=dtype)
                        kernel   = torch.zeros([out_channel,in_channel,kernel_size,kernel_size], dtype=dtype)
                        if tbias is None: bias = None
                        else: bias = torch.ones([out_channel], dtype=dtype)*tbias
                        in_data, kernel, bias = GenData(in_data, kernel, bias, dtype, random=random)
                        for stride in _strides:
                            for padding in _paddings:
                                if padding > kernel_size/2:
                                    count_passed+=1
                                    continue
                                # note that these are torch not numpy
                                result, out_data, nout_data = TestConvolution2d(dtype, in_data, kernel, bias, stride, padding, rigor=rigor, verbose=verbose)
                                if result: 
                                    dlr_common.DlrInfo(f"OK", flush=True)
                                    count_ok+=1
                                else:
                                    dlr_common.DlrInfo("mis-match", flush=True)
                                    count_fail+=1
                                    _fail_case.append({ 'in_channel': in_channel
                                                      , 'out_channel': out_channel
                                                      , 'in_size': in_size
                                                      , 'kernel_size': kernel_size
                                                      , 'stride': stride
                                                      , 'padding': padding
                                                      , 'bias_size': 0 if bias is None else len(bias)
                                                      #, 'pytorch_result': out_data
                                                      #, 'cprogram_result': nout_data 
                                                      })
                            #for padding in _paddings:
                        #for stride in _strides:
                    #for tbias in _biases:
                #for kernel_size in _kernel_sizes:
            #for in_size in _in_sizes:
        #for out_channel in _out_channels:
    #for in_channel in _in_channels:

    #count_fail = count_all-count_ok-count_passed
    dlr_common.DlrInfo(f"[match={count_ok}(bypass={count_passed})/All={count_all}], mis-match={count_fail}", flush=True)
    if count_fail>0:
        import pprint
        dlr_common.DlrInfo("[failed case]", flush=True)
        pprint.pprint(_fail_case, indent=4)
    
if __name__=='__main__':
    import argparse

    parser = argparse.ArgumentParser(description='Convolution 2D Testing')

    parser.add_argument('--dtype', dest='dtype', type=str, default='int32',
                        help='Specify data type (default: int32) float32, float64')
    parser.add_argument('--random', dest='random', action='store_true', default=False,
                        help='Use random pattern (default: False)')
    parser.add_argument('--rigor', dest='rigor', action='store_true', default=False,
                        help='Check values rigorously (default: False)')
    parser.add_argument('--verbose', dest='verbose', action='store_true', default=False,
                        help='Set verbose (default: False)')

    args = parser.parse_args()
    random = args.random
    rigor = args.rigor
    verbose = args.verbose
    dtype = { 'int32'   : torch.int32,
              'float32' : torch.float32,
              'float64' : torch.float64
            } [args.dtype]

    #print(f"dtype={dtype} rigor={rigor} random={random}")

    dlr_common.DlrInfo("Testing Convolution2d", flush=True)
    TestConvolution2dAll(dtype=dtype,random=random,rigor=rigor,verbose=verbose)

#===============================================================================
# Revision History:
#
# 2020.09.30: mini-batch supported
#===============================================================================
