#!/bin/bash

/bin/rm -f  hls_project.log
/bin/rm -f  vivado_hls.log vitis_hls.log
/bin/rm -f  vivado.log vivado.jou
/bin/rm -fr .Xil
/bin/rm -f  test
/bin/rm -rf convolution_2d
